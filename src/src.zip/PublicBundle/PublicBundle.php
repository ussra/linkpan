<?php

namespace PublicBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PublicBundle extends Bundle
{
}
