<?php

namespace PublicBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class LinkpanControllerTest extends WebTestCase
{
}
